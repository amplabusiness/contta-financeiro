# 🔄 FLUXO AUTOMATIZADO - VISÃO SIMPLIFICADA

```
╔════════════════════════════════════════════════════════════════════════════╗
║                     CICLO CONTÁBIL MENSAL AMPLA                            ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║  ┌─────────────────────────────────────────────────────────────────────┐  ║
║  │ DIA 30: PROVISÃO AUTOMÁTICA                                         │  ║
║  │                                                                     │  ║
║  │   ⏰ Cron Job                                                       │  ║
║  │      │                                                              │  ║
║  │      ▼                                                              │  ║
║  │   📦 Edge: gerar-honorarios                                         │  ║
║  │      │                                                              │  ║
║  │      │ Para cada cliente ativo:                                     │  ║
║  │      │                                                              │  ║
║  │      ▼                                                              │  ║
║  │   📝 Lançamento:                                                    │  ║
║  │      D - 1.1.2.01.xxxx (Cliente)     R$ 1.500                       │  ║
║  │      C - 3.1.1.01 (Receita)          R$ 1.500                       │  ║
║  │                                                                     │  ║
║  │   ✅ Cliente fica DEVENDO                                           │  ║
║  └─────────────────────────────────────────────────────────────────────┘  ║
║                                    │                                       ║
║                                    ▼                                       ║
║  ┌─────────────────────────────────────────────────────────────────────┐  ║
║  │ DIA 1-5: EMISSÃO DE BOLETOS                                         │  ║
║  │                                                                     │  ║
║  │   📦 Edge: emitir-boletos                                           │  ║
║  │      │                                                              │  ║
║  │      ├──▶ Gera boletos individuais                                  │  ║
║  │      ├──▶ Agrupa em cobrança (COB000030)                            │  ║
║  │      └──▶ Envia ao Sicredi                                          │  ║
║  │                                                                     │  ║
║  │   📄 Arquivo gerado: COBRANCA_202501.rem                            │  ║
║  └─────────────────────────────────────────────────────────────────────┘  ║
║                                    │                                       ║
║                                    ▼                                       ║
║  ┌─────────────────────────────────────────────────────────────────────┐  ║
║  │ DIA 5-10: CLIENTES PAGAM                                            │  ║
║  │                                                                     │  ║
║  │   💰 Banco recebe pagamentos                                        │  ║
║  │   📄 Sicredi gera arquivo de retorno                                │  ║
║  └─────────────────────────────────────────────────────────────────────┘  ║
║                                    │                                       ║
║                                    ▼                                       ║
║  ┌─────────────────────────────────────────────────────────────────────┐  ║
║  │ DIA 10-15: IMPORTAR OFX                                             │  ║
║  │                                                                     │  ║
║  │   👤 Usuário faz upload do OFX                                      │  ║
║  │      │                                                              │  ║
║  │      ▼                                                              │  ║
║  │   📦 Storage: /imports/ofx/2025-01/extrato.ofx                      │  ║
║  │      │                                                              │  ║
║  │      │ Trigger automático                                           │  ║
║  │      ▼                                                              │  ║
║  │   📦 Edge: processar-ofx                                            │  ║
║  │      │                                                              │  ║
║  │      ├──▶ Cobrança agrupada? (COB000030)                            │  ║
║  │      │       │                                                      │  ║
║  │      │       ▼                                                      │  ║
║  │      │    📝 D - 1.1.1.05 (Banco)        R$ 12.500                   │  ║
║  │      │       C - 1.1.9.01 (Transitória)  R$ 12.500                   │  ║
║  │      │                                                              │  ║
║  │      ├──▶ PIX identificável? (Cliente João)                         │  ║
║  │      │       │                                                      │  ║
║  │      │       ▼                                                      │  ║
║  │      │    📝 D - 1.1.1.05 (Banco)        R$ 800                      │  ║
║  │      │       C - 1.1.2.01.0015 (João)    R$ 800                      │  ║
║  │      │                                                              │  ║
║  │      ├──▶ PIX não identificado?                                     │  ║
║  │      │       │                                                      │  ║
║  │      │       ▼                                                      │  ║
║  │      │    📝 D - 1.1.1.05 (Banco)        R$ 200                      │  ║
║  │      │       C - 1.1.2.01.9999 (Pendente) R$ 200                     │  ║
║  │      │                                                              │  ║
║  │      └──▶ Despesa? (Conta de luz)                                   │  ║
║  │              │                                                      │  ║
║  │              ▼                                                      │  ║
║  │           📝 D - 4.1.1.01 (Energia)      R$ 350                      │  ║
║  │              C - 1.1.1.05 (Banco)        R$ 350                      │  ║
║  │                                                                     │  ║
║  │   ⚠️ Transitória com saldo = aguarda desmembramento                 │  ║
║  └─────────────────────────────────────────────────────────────────────┘  ║
║                                    │                                       ║
║                                    ▼                                       ║
║  ┌─────────────────────────────────────────────────────────────────────┐  ║
║  │ DIA 15-20: DESMEMBRAR COBRANÇA                                      │  ║
║  │                                                                     │  ║
║  │   👤 Usuário faz upload do arquivo de retorno Sicredi               │  ║
║  │      │                                                              │  ║
║  │      ▼                                                              │  ║
║  │   📦 Edge: desmembrar-cobranca                                      │  ║
║  │      │                                                              │  ║
║  │      │ Lê arquivo → identifica clientes → baixa cada um             │  ║
║  │      │                                                              │  ║
║  │      ▼                                                              │  ║
║  │   📝 Lançamento ÚNICO:                                              │  ║
║  │      D - 1.1.9.01 (Transitória)     R$ 12.500 (estorno)             │  ║
║  │      C - 1.1.2.01.0001 (Cliente A)  R$  1.500                        │  ║
║  │      C - 1.1.2.01.0002 (Cliente B)  R$  2.000                        │  ║
║  │      C - 1.1.2.01.0003 (Cliente C)  R$  1.800                        │  ║
║  │      ... (N clientes)                                               │  ║
║  │      C - 1.1.2.01.00NN (Cliente N)  R$  7.200                        │  ║
║  │                                                                     │  ║
║  │   ✅ Transitória ZERADA                                             │  ║
║  │   ✅ Cada cliente BAIXADO                                           │  ║
║  └─────────────────────────────────────────────────────────────────────┘  ║
║                                    │                                       ║
║                                    ▼                                       ║
║  ┌─────────────────────────────────────────────────────────────────────┐  ║
║  │ VERIFICAÇÃO FINAL                                                   │  ║
║  │                                                                     │  ║
║  │   📦 MCP: diagnostico_completo                                      │  ║
║  │                                                                     │  ║
║  │   ✅ Equação contábil: D = C                                        │  ║
║  │   ✅ Conta sintética: 0 lançamentos                                 │  ║
║  │   ✅ Transitória: Saldo R$ 0,00                                     │  ║
║  │   ✅ Banco: Saldo = OFX                                             │  ║
║  └─────────────────────────────────────────────────────────────────────┘  ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝


╔════════════════════════════════════════════════════════════════════════════╗
║                          PAPÉIS NO SISTEMA                                 ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║   ┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐       ║
║   │    USUÁRIO      │    │   DR. CÍCERO    │    │  MCP FINANCEIRO │       ║
║   │    (Sérgio)     │    │  (Assistente)   │    │   (Guardião)    │       ║
║   └────────┬────────┘    └────────┬────────┘    └────────┬────────┘       ║
║            │                      │                      │                 ║
║            │ "Importa OFX"        │                      │                 ║
║            │─────────────────────▶│                      │                 ║
║            │                      │                      │                 ║
║            │                      │ Chama ferramenta     │                 ║
║            │                      │─────────────────────▶│                 ║
║            │                      │                      │                 ║
║            │                      │                      │ VALIDA:         ║
║            │                      │                      │ - Sintética? ❌ ║
║            │                      │                      │ - D = C? ✅     ║
║            │                      │                      │ - Duplicado? ❌ ║
║            │                      │                      │                 ║
║            │                      │     OK ou ERRO       │                 ║
║            │                      │◀─────────────────────│                 ║
║            │                      │                      │                 ║
║            │    Resultado         │                      │                 ║
║            │◀─────────────────────│                      │                 ║
║            │                      │                      │                 ║
║                                                                            ║
║   RESUMO:                                                                  ║
║   • Usuário → Inicia ações (upload, comandos)                              ║
║   • Cícero  → Interpreta e orquestra                                       ║
║   • MCP     → Valida TUDO antes de executar (BLOQUEADOR)                   ║
║   • Edge    → Executa processamento pesado                                 ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝


╔════════════════════════════════════════════════════════════════════════════╗
║                       CONTAS DE DESPESA (CADA UMA NA SUA)                  ║
╠════════════════════════════════════════════════════════════════════════════╣
║                                                                            ║
║   4. DESPESAS                                                              ║
║   ├── 4.1 DESPESAS OPERACIONAIS                                           ║
║   │   ├── 4.1.1 Utilidades                                                ║
║   │   │   ├── 4.1.1.01 Energia Elétrica                                   ║
║   │   │   ├── 4.1.1.02 Água e Esgoto                                      ║
║   │   │   ├── 4.1.1.03 Telefone e Internet                                ║
║   │   │   └── 4.1.1.04 Gás                                                ║
║   │   │                                                                   ║
║   │   ├── 4.1.2 Consumo                                                   ║
║   │   │   ├── 4.1.2.01 Material de Escritório                             ║
║   │   │   ├── 4.1.2.02 Material de Limpeza                                ║
║   │   │   ├── 4.1.2.03 Combustível                                        ║
║   │   │   └── 4.1.2.04 Alimentação/Refeições                              ║
║   │   │                                                                   ║
║   │   ├── 4.1.3 Serviços                                                  ║
║   │   │   ├── 4.1.3.01 Serviços de TI/Software                            ║
║   │   │   ├── 4.1.3.02 Honorários Advocatícios                            ║
║   │   │   ├── 4.1.3.03 Serviços Contábeis                                 ║
║   │   │   ├── 4.1.3.04 Marketing/Publicidade                              ║
║   │   │   └── 4.1.3.05 Manutenção/Reparos                                 ║
║   │   │                                                                   ║
║   │   └── 4.1.4 Ocupação                                                  ║
║   │       ├── 4.1.4.01 Aluguel                                            ║
║   │       ├── 4.1.4.02 Condomínio                                         ║
║   │       ├── 4.1.4.03 IPTU                                               ║
║   │       └── 4.1.4.04 Seguro do Imóvel                                   ║
║   │                                                                       ║
║   ├── 4.2 DESPESAS COM PESSOAL                                            ║
║   │   ├── 4.2.1.01 Salários                                               ║
║   │   ├── 4.2.1.02 INSS Patronal                                          ║
║   │   ├── 4.2.1.03 FGTS                                                   ║
║   │   ├── 4.2.1.04 Vale Transporte                                        ║
║   │   ├── 4.2.1.05 Vale Alimentação                                       ║
║   │   └── 4.2.1.06 Pró-labore                                             ║
║   │                                                                       ║
║   ├── 4.3 DESPESAS FINANCEIRAS                                            ║
║   │   ├── 4.3.1.01 Juros Bancários                                        ║
║   │   ├── 4.3.1.02 Tarifas Bancárias                                      ║
║   │   ├── 4.3.1.03 IOF                                                    ║
║   │   └── 4.3.1.04 Multas e Juros Pagos                                   ║
║   │                                                                       ║
║   ├── 4.4 IMPOSTOS E TAXAS                                                ║
║   │   ├── 4.4.1.01 ISS                                                    ║
║   │   ├── 4.4.1.02 PIS                                                    ║
║   │   ├── 4.4.1.03 COFINS                                                 ║
║   │   ├── 4.4.1.04 IRPJ                                                   ║
║   │   └── 4.4.1.05 CSLL                                                   ║
║   │                                                                       ║
║   └── 4.9 OUTRAS DESPESAS                                                 ║
║       └── 4.9.9.01 Despesas a Classificar                                 ║
║                                                                            ║
║   ⚠️ REGRA: Cada despesa na sua conta específica!                         ║
║   ⚠️ NUNCA: Várias despesas em "Despesas Diversas"                        ║
║                                                                            ║
╚════════════════════════════════════════════════════════════════════════════╝
```
